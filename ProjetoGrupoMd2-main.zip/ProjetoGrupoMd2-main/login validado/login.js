class Erro extends Error{
    constructor(message){
        super(message)
        this.name = "Erro de entrada de dados"
    }
}

const msg = '{"tipo":"Ana"}'

try {

    const { tipo } = JSON.parse(msg)

    if (tipo=="Ana"){
        console.log("Seja bem vinda")
    }
    else{
        throw new Erro("Usuário nao Encontrado")
    }

} catch (error){
    console.log(error.name)
    console.log(error.message)
}